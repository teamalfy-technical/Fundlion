/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image2', 'sr-latn', {
	alt: 'Alternativni tekst',
	btnUpload: 'Pošalji na server',
	captioned: 'Slika sa natpisom',
	captionPlaceholder: 'Natpis',
	infoTab: 'Osnovne karakteristike',
	lockRatio: 'Zadrži odnos',
	menu: 'Osobine slike',
	pathName: 'Slika',
	pathNameCaption: 'Natpis',
	resetSize: 'Original  veličina',
	resizer: 'Kliknite i povucite da bi ste promenili veličinu',
	title: 'Osobine slika',
	uploadTab: 'Postavi',
	urlMissing: 'Nedostaje URL slike',
	altMissing: 'Nedostaje alternativni tekst'
} );
