/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image2', 'th', {
	alt: 'คำประกอบรูปภาพ',
	btnUpload: 'อัพโหลดไฟล์ไปเก็บไว้ที่เครื่องแม่ข่าย (เซิร์ฟเวอร์)',
	captioned: 'Captioned image', // MISSING
	captionPlaceholder: 'Caption', // MISSING
	infoTab: 'ข้อมูลของรูปภาพ',
	lockRatio: 'กำหนดอัตราส่วน กว้าง-สูง แบบคงที่',
	menu: 'คุณสมบัติของ รูปภาพ',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'กำหนดรูปเท่าขนาดจริง',
	resizer: 'Click and drag to resize', // MISSING
	title: 'คุณสมบัติของ รูปภาพ',
	uploadTab: 'อัพโหลดไฟล์',
	urlMissing: 'Image source URL is missing.', // MISSING
	altMissing: 'Alternative text is missing.' // MISSING
} );
